import os
import win32com.client
import pythoncom

def extract_vba_code(file_path):
    pythoncom.CoInitialize()  # Initialize the COM library
    try:
        excel = win32com.client.Dispatch("Excel.Application")
        full_file_path = os.path.abspath(file_path)
        workbook = None
        try:
            workbooks = excel.Workbooks
            workbook = workbooks.Open(full_file_path, ReadOnly=True)
            vba_code = {}
            for vb_component in workbook.VBProject.VBComponents:
                if vb_component.Type in [1, 2, 3]:  # Module, Class Module, Form
                    code_module = vb_component.CodeModule
                    code = code_module.Lines(1, code_module.CountOfLines)
                    vba_code[vb_component.Name] = code
            return vba_code
        finally:
            if workbook:
                workbook.Close(SaveChanges=False)
            excel = None  # Release the Excel application reference
    finally:
        pythoncom.CoUninitialize()  # Uninitialize the COM library