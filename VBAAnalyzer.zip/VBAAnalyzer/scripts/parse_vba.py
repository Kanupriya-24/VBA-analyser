import re

def parse_vba_code(vba_code):
    functions = []
    for module_name, code in vba_code.items():
        matches = re.findall(r'(Sub|Function)\s+(\w+)\s*\((.*?)\)', code, re.DOTALL)
        for match in matches:
            func_type, name, params = match
            functions.append({
                'module': module_name,
                'type': func_type,
                'name': name,
                'params': params.strip(),
                'body': extract_function_body(code, name)
            })
    return functions

def extract_function_body(code, function_name):
    pattern = rf'{function_name}\s*\(.*?\)(.*?)(End\s+Sub|End\s+Function)'
    match = re.search(pattern, code, re.DOTALL)
    return match.group(1).strip() if match else ''
