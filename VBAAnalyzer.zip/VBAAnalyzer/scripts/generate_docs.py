from jinja2 import Template

def generate_documentation(functions):
    template_str = """
    {% for function in functions %}
    <div style="border: 1px solid #000; padding: 15px; margin-bottom: 20px;">
        <h2 style="color: #2E86C1;">{{ function.name }}</h2>
        <p><strong>Type:</strong> {{ function.type }}</p>
        <p><strong>Module:</strong> {{ function.module }}</p>

        <h3 style="color: #1F618D;">Parameters:</h3>
        {% if function.params %}
        <ul>
            {% for param in function.params %}
            <li><strong>{{ param.name }}:</strong> ({{ param.type }}) - {{ param.description }}</li>
            {% endfor %}
        </ul>
        {% else %}
        <p>No parameters.</p>
        {% endif %}

        <h3 style="color: #1F618D;">Function Body:</h3>
        <pre style="background-color: #F2F3F4; padding: 10px; border-radius: 5px;">
        {{ function.body }}
        </pre>

        <h3 style="color: #1F618D;">Logic Analysis:</h3>
        {% if function.logic %}
        <ul>
            {% for logic in function.logic %}
            <li><strong>{{ logic.type }}:</strong> {{ logic.line }}</li>
            {% endfor %}
        </ul>
        {% else %}
        <p>No logic analysis available.</p>
        {% endif %}
    </div>
    {% endfor %}
    """
    template = Template(template_str)
    documentation = template.render(functions=functions)
    with open('documentation.md', 'w') as f:
        f.write(documentation)
