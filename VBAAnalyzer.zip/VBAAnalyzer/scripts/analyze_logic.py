import re

def analyze_logic(functions):
    for function in functions:
        function['logic'] = []
        lines = function['body'].split('\n')
        for line in lines:
            line = line.strip()
            # Check for conditionals
            if line.startswith('If ') or line.startswith('ElseIf '):
                function['logic'].append({'type': 'conditional', 'line': line})
            elif line.startswith('Else'):
                function['logic'].append({'type': 'else', 'line': line})
            elif line.startswith('Select Case'):
                function['logic'].append({'type': 'select case', 'line': line})
            elif line.startswith('Case '):
                function['logic'].append({'type': 'case', 'line': line})
            # Check for loops
            elif line.startswith('For ') or line.startswith('While ') or line.startswith('Do '):
                function['logic'].append({'type': 'loop', 'line': line})
            elif line.startswith('Next') or line.startswith('Loop'):
                function['logic'].append({'type': 'loop end', 'line': line})
            # Check for assignments
            elif re.match(r'^\w+\s*=', line):
                function['logic'].append({'type': 'assignment', 'line': line})
            # Check for function calls
            elif re.match(r'^\w+\s*\(.*\)', line):
                function['logic'].append({'type': 'function call', 'line': line})
            # Check for error handling
            elif line.startswith('On Error'):
                function['logic'].append({'type': 'error handling', 'line': line})
            elif line.startswith('Resume'):
                function['logic'].append({'type': 'resume', 'line': line})
    return functions