import unittest
from scripts.analyze_logic import analyze_logic

class TestAnalyzeLogic(unittest.TestCase):

    def test_analyze_logic(self):
        functions = [{
            'module': 'Module1',
            'type': 'Sub',
            'name': 'TestSub',
            'params': '',
            'body': """
            Dim x As Integer
            x = 5
            If x > 3 Then
                x = x + 1
            End If
            """
        }]
        analyzed_functions = analyze_logic(functions)
        self.assertIsInstance(analyzed_functions, list)
        self.assertEqual(len(analyzed_functions[0]['logic']), 3)
        self.assertEqual(analyzed_functions[0]['logic'][0]['type'], 'assignment')
        self.assertEqual(analyzed_functions[0]['logic'][1]['type'], 'conditional')

if __name__ == '__main__':
    unittest.main()
