import unittest
import os
from scripts.generate_docs import generate_documentation

class TestGenerateDocs(unittest.TestCase):

    def test_generate_documentation(self):
        functions = [{
            'module': 'Module1',
            'type': 'Sub',
            'name': 'TestSub',
            'params': '',
            'body': """
            Dim x As Integer
            x = 5
            If x > 3 Then
                x = x + 1
            End If
            """
        }]
        generate_documentation(functions)
        self.assertTrue(os.path.exists('documentation.md'))
        with open('documentation.md', 'r') as f:
            content = f.read()
            self.assertIn('TestSub', content)

if __name__ == '__main__':
    unittest.main()
