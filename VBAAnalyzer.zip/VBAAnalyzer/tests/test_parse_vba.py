import unittest
from scripts.parse_vba import parse_vba_code

class TestParseVBA(unittest.TestCase):

    def test_parse_vba_code(self):
        vba_code = {
            'Module1': """
            Sub TestSub()
                Dim x As Integer
                x = 5
                If x > 3 Then
                    x = x + 1
                End If
            End Sub
            """
        }
        functions = parse_vba_code(vba_code)
        self.assertIsInstance(functions, list)
        self.assertEqual(len(functions), 1)
        self.assertEqual(functions[0]['name'], 'TestSub')

if __name__ == '__main__':
    unittest
