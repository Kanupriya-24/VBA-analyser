import unittest
from scripts.extract_vba import extract_vba_code

class TestExtractVBA(unittest.TestCase):

    def test_extract_vba_code(self):
        # This test requires a sample Excel file with VBA macros to be present in the uploads directory
        file_path = 'uploads/sample.xlsm'
        vba_code = extract_vba_code(file_path)
        self.assertIsInstance(vba_code, dict)
        self.assertTrue(len(vba_code) > 0)

if __name__ == '__main__':
    unittest.main()
