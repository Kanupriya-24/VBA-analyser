
    
    <div style="border: 1px solid #000; padding: 15px; margin-bottom: 20px;">
        <h2 style="color: #2E86C1;">SumValues</h2>
        <p><strong>Type:</strong> Function</p>
        <p><strong>Module:</strong> Module1</p>

        <h3 style="color: #1F618D;">Parameters:</h3>
        
        <ul>
            
            <li><strong>:</strong> () - </li>
            
            <li><strong>:</strong> () - </li>
            
            <li><strong>:</strong> () - </li>
            
            <li><strong>:</strong> () - </li>
            
            <li><strong>:</strong> () - </li>
            
            <li><strong>:</strong> () - </li>
            
            <li><strong>:</strong> () - </li>
            
            <li><strong>:</strong> () - </li>
            
            <li><strong>:</strong> () - </li>
            
            <li><strong>:</strong> () - </li>
            
            <li><strong>:</strong> () - </li>
            
            <li><strong>:</strong> () - </li>
            
        </ul>
        

        <h3 style="color: #1F618D;">Function Body:</h3>
        <pre style="background-color: #F2F3F4; padding: 10px; border-radius: 5px;">
        As Double
    Dim cell As Range
    Dim total As Double
    total = 0
    
    ' Loop through each cell in the range
    For Each cell In rng
        ' Check if the cell contains a numeric value
        If IsNumeric(cell.Value) Then
            total = total + cell.Value
        End If
    Next cell
    
    SumValues = total
        </pre>

        <h3 style="color: #1F618D;">Logic Analysis:</h3>
        
        <ul>
            
            <li><strong>assignment:</strong> total = 0</li>
            
            <li><strong>loop:</strong> For Each cell In rng</li>
            
            <li><strong>conditional:</strong> If IsNumeric(cell.Value) Then</li>
            
            <li><strong>assignment:</strong> total = total + cell.Value</li>
            
            <li><strong>loop end:</strong> Next cell</li>
            
            <li><strong>assignment:</strong> SumValues = total</li>
            
        </ul>
        
    </div>
    
    