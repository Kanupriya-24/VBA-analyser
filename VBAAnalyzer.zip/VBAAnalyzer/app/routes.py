from flask import request, render_template, redirect, url_for
from app import app
from scripts.extract_vba import extract_vba_code
from scripts.parse_vba import parse_vba_code
from scripts.analyze_logic import analyze_logic
from scripts.generate_docs import generate_documentation

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        file = request.files['file']
        if file:
            file_path = f"uploads/{file.filename}"
            file.save(file_path)
            vba_code = extract_vba_code(file_path)
            parsed_functions = parse_vba_code(vba_code)
            analyzed_functions = analyze_logic(parsed_functions)
            generate_documentation(analyzed_functions)
            
            return redirect(url_for('documentation'))
    return render_template('upload.html')

@app.route('/documentation')
def documentation():
    with open('documentation.md', 'r') as f:
        doc_content = f.read()
    return render_template('documentation.html', content=doc_content)
